#include <iostream>
#include <SFML/Graphics.hpp>
#include "gol.h"
#include"constants.h"
#include"game.h"

using namespace std;
using namespace sf;

int main(int argc, char *argv[])
{
    game g;
    g.run();
     return 0;
}

