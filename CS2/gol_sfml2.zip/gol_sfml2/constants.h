#ifndef CONSTANTS_H
#define CONSTANTS_H



const double SCREEN_WIDTH = 1500;
const double SCREEN_HEIGHT = 1500;
const int box_s=50;
const int small_box_s=10;
const int small_box_gap =1;
const int small_box_x =(25*50)+50;
const int small_box_y =20+25*18;
const int gap=2;
const int box_x=5;
const int box_y=20;
const int gap_n_box_s=52;
const char FILE_NAME[]="gol.txt";
//add 25 to every text box x for every one added to m_row(10)
const int text_box_x=(25*50)+50;
const int text_box_y=20;
const int num_of_text=6;
const int text_box_w=125;
const int m_row=25;
const int m_col=25;
const int max_col=100;

#endif // CONSTANTS_H
